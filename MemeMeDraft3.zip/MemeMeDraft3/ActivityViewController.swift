//
//  ActivityViewController.swift
//  MemeMeDraft3
//
//  Created by ALCALY LO on 12/29/17.
//  Copyright © 2017 ALCALY LO. All rights reserved.
//

import UIKit

class ActivityViewController: UIViewController {
    
    
    
    
    override func viewWillAppear(_ animated: Bool){
        
        super.viewWillAppear(animated)
        
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    
    
}
